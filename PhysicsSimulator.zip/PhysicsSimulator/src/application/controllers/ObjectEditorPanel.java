package application.controllers;

import javafx.scene.layout.VBox;

public class ObjectEditorPanel {
	
	Object e;
	VBox box;
	
	public ObjectEditorPanel(Object e) {
		this.e = e;
	}

}
